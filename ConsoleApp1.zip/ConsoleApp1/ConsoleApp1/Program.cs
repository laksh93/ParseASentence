﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
   public class Program
    {
       public  static void Main(string[] args)
        {
            var str = "Space Separated";
            var ret = StringSplit.Decode(str);
            Console.Write(ret);

        }
    }

    public class StringSplit
    {
        public static string Decode(string str)
        {
            if (string.IsNullOrWhiteSpace(str))
                return str;
            var reset = true;
            var ret = string.Empty;
            var count = new List<char>();
            for (var s = 0; s < str.Length; s++)
            {
                if ((str[s] - 'A' >= 0 || str[s] - 'a' >= 0) && (str[s] - 'Z' <= 0 || str[s] - 'z' <= 0))//only it is alphabetic character
                {
                    if (reset)
                    {
                        //first character of string
                        ret += str[s];
                        reset = false;
                    }
                    else if ((s + 1 == str.Length) || (s + 1 < str.Length && !((str[s + 1] - 'A' >= 0 || str[s + 1] - 'a' >= 0) && (str[s + 1] - 'Z' <= 0 || str[s + 1] - 'z' <= 0))))
                    {
                        //end character of string or end of string
                        ret += count.Count;
                        ret += str[s];
                    }
                    else if (!count.Contains(str[s]))//add unique characters only
                    {
                        count.Add(str[s]);
                    }
                }
                else // non-alphabetic character
                {
                    count = new List<char>();
                    reset = true;
                    ret += str[s];
                }
            }

            return ret;
        }
    }
}
